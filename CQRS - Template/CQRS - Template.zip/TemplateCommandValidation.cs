﻿
using FluentValidation;

namespace $rootnamespace$.$fileinputname$.Commands
{
    public class Create$fileinputname$CommandValidator : AbstractValidator<Create$fileinputname$Command>
    {
        public Create$fileinputname$CommandValidator()
        {
            throw new System.NotImplementedException();
        }
    }
}

