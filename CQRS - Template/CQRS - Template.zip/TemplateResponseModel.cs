﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;

namespace $rootnamespace$.$fileinputname$.Responses
{
    public class $fileinputname$ResponseModel
    {
        public int Id { get; set; }
    }
}
